# for i in range(3):
#     print(i)

# for i in range(2, 6):
#     print(i)

# for i in range(2,11,2):
#     print(i)

# for i in range(5):
#     for j in range(5):
#         print('*',end="")
#     print("")

# for i in range(5):
#     for j in range(i+1):
#         print("*",end="")
#     print("")
    
i=0
while i<=5:
    print(i)
    i+=1

